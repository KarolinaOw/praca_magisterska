from .format import draw_logo

print(draw_logo().decode())
